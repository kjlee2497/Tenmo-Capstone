package com.techelevator.tenmo.model;

public class Username {
    private String Username;

    public Username() {
    }

    public Username(String username) {
        Username = username;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
